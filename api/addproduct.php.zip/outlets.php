<?php
  
  include("../connect.php");
 $time=date("H:i:s"); 
  $datetime = date("Y-m-d H:i:s");
  $date=date("Y-m-d");
  function truncate_number( $number, $precision = 2) {
    // Zero causes issues, and no need to truncate
    if ( 0 == (int)$number ) {
        return $number;
    }
    // Are we negative?
    $negative = $number / abs($number);
    // Cast the number to a positive to solve rounding
    $number = abs($number);
    // Calculate precision number for dividing / multiplying
    $precision = pow(10, $precision);
    // Run the math, re-applying the negative value to ensure returns correctly negative / positive
    return floor( $number * $precision ) / $precision * $negative;
    }
  
   if(isset($_GET['new']))
   {
	  
	  extract($_POST);
	  $filename=$_FILES['lastvisitpic']['name'];
	  $tmpname=$_FILES['lastvisitpic']['tmp_name'];
	  $filename=$name.$contact.$filename.".jpg";
	  $response=array();
	  
	  $lat=truncate_number($latitude,3);
	  $lng=truncate_number($longitude,3);
	  
	  $res=mysqli_query($con,"select * from outlets where outlettype='$outlettype' and state='$state' and city='$city' contactperson='$contactperson' and contact='$contact' and truncate(latitude,3)='$lat' and truncate(longitude,3)='$lng'");
	  if($row=mysqli_fetch_array($res))
	   {
		 $response["message"]="already";
		 echo json_encode($response); 
		 return;   
	   }
	  
	  mysqli_query($con,"insert into outlets(name,address,lastvisitpic,contactperson,contact,pincode,gstnumber,outlettype,outletsubtype,distributorid,routeid,competitor_presense,street,locality,city,state,latitude,longitude,areaid,lastvisit,creationdate,createdby) values('$name','$address','$filename','$contactperson','$contact','$pincode','$gstnumber','$outlettype','$outletsubtype','$distributorid','0','$competitor_presense','$street','$locality','$city','$state','$latitude','$longitude','$areaid','$datetime','$datetime','$createdby')");
	  
	  if(mysqli_affected_rows($con)>0)
	  {
		  $outletid=mysqli_insert_id($con);
		mysqli_query($con,"insert into outletactivity(userid,outletid,activitytype,battery,activitydate,activitytime) values('$createdby','$outletid','New Outlet','$battery%','$date','$time')")or die(mysqli_error($con));
		
		  if(move_uploaded_file($tmpname,"../imgoutlets/".$filename))
		  {
		    $response["message"]="success";
		  }
		  else
	      {
		   $response["message"]="error";
	      }
	  }
	  else
	  {
		   $response["message"]="error";
	  }
	   
	    echo json_encode($response); 
   }
   if(isset($_GET['visitregister']))
   {
	  extract($_POST);
	  $filename=$_FILES['lastvisitpic']['name'];
	  $tmpname=$_FILES['lastvisitpic']['tmp_name'];
	  $filename=$name.$contact.$filename.".jpg";
	  $response=array();
	  	  
	  mysqli_query($con,"update  outlets set lastvisitpic='$filename',lastvisit=now() where id='$id'")or die(mysqli_error($con));
	  
	  if(mysqli_affected_rows($con)>0)
	  {
		  
		  mysqli_query($con,"insert into outletactivity(userid,outletid,activitytype,battery,activitydate,activitytime) values('$userid','$id','Visit','$battery%','$date','$time')")or die(mysqli_error($con));
		 
		   $entryid=mysqli_insert_id($con);
		  
		  if(move_uploaded_file($tmpname,"../imgoutlets/".$filename))
		  {
		    $response["message"]="success";
			$response["entryid"]=$entryid;
		  }
		  else
	      {
		    $response["message"]="error";
	      }
	  }
	  else
	  {
		   $response["message"]="error";
	  }
	   
	    echo json_encode($response); 
 
   }


if(isset($_GET['feedback']))
   {
	  extract($_POST);
	  $response=array();
	  	  
	  mysqli_query($con,"update  outletactivity set feedback='$feedback', rating='$rating' where id='$id'")or die(mysqli_error($con));
	  
	  if(mysqli_affected_rows($con)>0)
	  {
		    $response["message"]="success";
	  }
	  else
	  {
		   $response["message"]="error";
	  }
	   
	    echo json_encode($response); 
 
   }


   if(isset($_GET['show']))
   {
	   extract($_REQUEST);
	   //$res=mysqli_query($con,"select * from outlets where areaid='$areaid'");
	   $lat=truncate_number($lat,0);
	   $lng=truncate_number($lng,0);
	  
	   $res=mysqli_query($con,"select * from outlets where truncate(latitude,0)='$lat' and truncate(longitude,0)='$lng'");
	   //$res=mysqli_query($con,"select * from outlets");
	   
	   $response=array();
	   $num=mysqli_field_count($con);
	   while($row=mysqli_fetch_array($res))
	   {
		   $rr=array();
		   $rr["id"]=$row["id"];
		   $rr["name"]=$row["name"];
		   $rr["address"]=$row['address'];
		   $rr["lastvisitpic"]=$row["lastvisitpic"];
		   $rr["contactperson"]=$row["contactperson"];
		   $rr["contact"]=$row["contact"];
		   $rr["pincode"]=$row["pincode"];
		   $rr["gstnumber"]=$row["gstnumber"];
		   $rr["outlettype"]=$row["outlettype"];
		   $rr["competitor_presense"]=$row["competitor_presense"];
		   $rr["distributorid"]=$row["distributorid"];
		   $rr["salesmanagerid"]=$row["salesmanagerid"];
		   $rr["rsmid"]=$row["rsmid"];
		   $rr["routeid"]=$row["routeid"];
		   $rr["street"]=$row["street"];
		   $rr["locality"]=$row["locality"];
		   $rr["city"]=$row["city"];
		   $rr["state"]=$row["state"];
		   $rr["latitude"]=$row["latitude"];
		   $rr["longitude"]=$row["longitude"];
		   $rr["areaid"]=$row["areaid"];
		   $rr["lastvisit"]=$row["lastvisit"];
		   $rr["creationdate"]=$row["creationdate"];
		   $rr["createdby"]=$row["createdby"]; 
		   array_push($response,$rr);
	   } 
	   $data=array();
	   $data["data"]=$response;
	   echo json_encode($data);
	   return; 
   }
?>