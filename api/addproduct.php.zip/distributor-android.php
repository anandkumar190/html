<?php

  require('../connect.php');
$time=date("H:i:s"); 
  $datetime = date("Y-m-d H:i:s");
  $date=date("Y-m-d");  
  function genrateId($con)
  {  
	  $query = "select empid from employees where usertype='3' order by empid desc";
	  //echo($pshort);
	  $res=mysqli_query($con,$query);
	  $id="";
	  if($row=mysqli_fetch_array($res)){
			$id=$row["empid"];
	  }
	  if($id=="")
	  return "DIS0001";
	  $id=(int)substr($id,3);
	  $id=$id+1;
	  
	  if($id>0 &&$id<10)
	  {
		  return"DIS000".$id;
	  }
	  if($id>9 &&$id<100)
	  {
		  return"DIS00".$id;
	  }
	  if($id>99 &&$id<1000)
	  {
		  return"DIS0".$id;
	  }
	  if($id>999)
	  {
		  return"DIS".$id;
	  }
  }
  
  
   function genrateSSId($con)
  {
	  
	  $query = "select empid from employees where usertype='2' order by empid desc";
	  //echo($pshort);
	  $res=mysqli_query($con,$query);
	  $id="";
	  if($row=mysqli_fetch_array($res)){
			$id=$row["empid"];
	  }
	  if($id=="")
	  return "SS0001";
	  $id=(int)substr($id,2);
	  $id++;
	  if($id>0 &&$id<10)
	  {
		  return"SS000".$id;
	  }
	  if($id>9 &&$id<100)
	  {
		  return"SS00".$id;
	  }
	  if($id>99 &&$id<1000)
	  {
		  return"SS0".$id;
	  }
	  if($id>999)
	  {
		  return"SS".$id;
	  }
  }

  
  if(isset($_GET['insert']))
  {
	  //$_POST=json_decode(file_get_contents("php://input"));
	  extract($_POST);
	  $response=array();
	  //var_dump($_POST);
	  if($usertype=="3")
	  {
	    $empcode=genrateId($con);
		  
	  }
	  if($usertype=="2")
	  {
	    $empcode=genrateSSId($con); 
	  }
	  
	  
	  $query = "select email from employees where email = '$empemail' and usertype='$usertype'";
	  $res=mysqli_query($con,$query);
	  if( mysqli_num_rows($res)> 0 ){
			$response["message"]="empemail";
			echo json_encode($response);
			return;
	  }
	  $query = "select contact from employees where contact = '$empcontact' and usertype='$usertype'";
	  $res=mysqli_query($con,$query);
	  if( mysqli_num_rows($res)> 0 ){
			$response["message"]="empcontact";
			echo json_encode($response);
			return;
			
	  }
	$filename=$_FILES['empimage']['name'];
	$tmpname=$_FILES['empimage']['tmp_name'];
	$filesize=$_FILES['empimage']['size'];
	$filetype=$_FILES['empimage']['type'];
	
	if($filesize>800000)
	{
	  echo"Image can't be Greater than 800KB .";
	  return;
	}
	
	$filename=$empname.$empcode.".jpg";
	mysqli_query($con,"insert into employees(image,name,empid,email,contact,address,designationid,roleid,managerid,usertype,password,salary,commission,city,state,reportsto,latitude,longitude,battery,region,doj,creationdate,createdby,stockistid,areaid) values('$filename','$empname','$empcode','$empemail','$empcontact','$empaddress','0','0','0','$usertype',password('$emppass'),'0','0','$city','$state','0','$lat','$lng','$pannumber','$gstnumber','$date','$datetime','$userid','$stockistid','$areaid')") or die(mysqli_error($con));
	
	$query="";
	if($usertype=="2")
	{
	  $query="insert into outletactivity(userid,outletid,activitytype,battery,activitydate,activitytime,feedback) values('$userid','0','Super Stockist Create','$battery%','$date','$time','New Super Stockist Create id is $empcode')";
	}
	else
	{
		$query="insert into outletactivity(userid,outletid,activitytype,battery,activitydate,activitytime,feedback) values('$userid','0','Distributor Create','$battery%','$date','$time','New Distributor Create id is $empcode')";
	}
	
	mysqli_query($con,$query);
	
	if(mysqli_affected_rows($con)>0)
	{
		
	  if(move_uploaded_file($tmpname,"../imgusers/".$filename))
	  {
		  $response["message"]="success";
			echo json_encode($response);
	  }
	  else
	  {
		  $response["message"]="error";
			echo json_encode($response);
	  }
	}
	
  }

  else if(isset($_GET['show']))
  {
	
     $res=mysqli_query($con,"select e.id, e.image, e.name, e.empid, e.email, e.contact, e.address, e.usertype, e.password, e.salary, e.commission, e.city, e.state, e.latitude, e.longitude, e.region, e.doj, e.dol, e.reportsto, e.creationdate ,e.stockistid,e.battery as 'panno',e.region as'gstno', emp.name as 'ssname' from  employees e join employees emp on emp.id=e.stockistid where e.usertype='3'");
	 $response=array();
	 
	 while($row=mysqli_fetch_array($res))
	 {
		 		 $rr=array("id"=>$row["id"],"name"=>$row["name"],"empid"=>$row["empid"],"email"=>$row["email"],"contact"=>$row["contact"],"address"=>$row["address"],"salary"=>$row["salary"],"commission"=>$row["commission"],"city"=>$row["city"],"latitude"=>$row["latitude"],"longitude"=>$row["longitude"],"panno"=>$row["panno"],"gstno"=>$row["gstno"],"image"=>$row["image"],"ssname"=>$row["ssname"]);
		 $response[]=$rr;
     }
	   $data=array();
	   $data["data"]=$response;	 
	   echo json_encode($data);
	 
  }

  else if(isset($_GET['edit']))
  {
	  //$_POST=json_decode(file_get_contents("php://input"));
	  extract($_POST);
	
	  //var_dump($_POST);
	  
	  $query = "select empid from employees where  empid = '$empcode' && id!='$id' and usertype='1'";
	  //echo($pshort);
	  $res=mysqli_query($con,$query);
	  if( mysqli_num_rows($res)> 0 ){
			echo "empcode";
			return;
	  }
	  $query = "select email from employees where email = '$empemail' and id!='$id' and usertype='1'";
	  $res=mysqli_query($con,$query);
	  if( mysqli_num_rows($res)> 0 ){
			echo "empemail";
			return;
	  }
	  $query = "select contact from employees where contact = '$empcontact' and id!='$id' and usertype='1'";
	  $res=mysqli_query($con,$query);
	  if(mysqli_num_rows($res)> 0 ){
			echo "empcontact";
			return;
	  }
	
	 if(isset($_FILES['empimage']['name']) && $_FILES['empimage']['name']!="" && !isset($_POST['empimage']) )
	  {
	     $filename=$_FILES['empimage']['name'];
	     $tmpname=$_FILES['empimage']['tmp_name'];
	     $filesize=$_FILES['empimage']['size'];
	     $filetype=$_FILES['empimage']['type'];
	     
		 if($filetype!="image/jpg" && $filetype!="image/png" &&   $filetype!="image/jpeg")
	     {
	       echo"Please Upload Images(PNG,JPG & JPEG) Files Only...";
 	       return;
      	 }
	     if($filesize>800000)
	     {
	       echo"Image can't be Greater than 800KB .";
	       return;
	     }
		  
	      $filename=$empname.$empcode.".jpg";
		  
		  if(file_exists("../imgusers".$filename))
		  {
			  unlink("../imgusers".$filename);
		  }
		  
	      mysqli_query($con,"update  employees set name='$empname',empid='$empcode',email='$empemail',contact='$empcontact',address='$empaddress',designationid='$empdesignation',roleid='$emprole',managerid='$empmanager',reportsto='$empreportto',salary='$empsalary',commission='$empcomm',doj='$empdoj',dol='$empdol',image='$filename' where id='$id'") or die(mysqli_error($con));
	      if(mysqli_affected_rows($con)>0)
       	  {
	       if(move_uploaded_file($tmpname,"../imgusers/".$filename))
	        {
	          echo"success";
	        }
	       else
	        {
             echo"Image error";
	        }
	      }
		  else
		  {
			 if(move_uploaded_file($tmpname,"../imgusers/".$filename))
	        {
	          echo"success";
	        }
	       else
	        {
             echo"Image error";
	        } 
		  }
	   }
	   else
	   {
		   
	      //$filename=$pname.$pshort.".jpg";
		  
	      mysqli_query($con,"update  employees set name='$empname',empid='$empcode',email='$empemail',contact='$empcontact',address='$empaddress',designationid='$empdesignation',roleid='$emprole',managerid='$empmanager',reportsto='$empreportto',salary='$empsalary',commission='$empcomm',doj='$empdoj',dol='$empdol' where id='$id'") or die(mysqli_error($con));
	      if(mysqli_affected_rows($con)>0)
       	  {
	          echo"success";  
	      }
		  else
		  {
			  echo"No changes affected...";
		  }
	   }
  }


?>